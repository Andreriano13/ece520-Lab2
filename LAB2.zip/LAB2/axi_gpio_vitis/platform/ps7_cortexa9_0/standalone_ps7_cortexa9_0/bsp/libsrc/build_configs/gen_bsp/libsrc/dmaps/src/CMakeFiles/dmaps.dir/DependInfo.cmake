
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/ECE520/LAB2/axi_gpio_vitis/platform/ps7_cortexa9_0/standalone_ps7_cortexa9_0/bsp/libsrc/dmaps/src/xdmaps.c" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps.c.obj" "gcc" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps.c.obj.d"
  "C:/ECE520/LAB2/axi_gpio_vitis/platform/ps7_cortexa9_0/standalone_ps7_cortexa9_0/bsp/libsrc/dmaps/src/xdmaps_g.c" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps_g.c.obj" "gcc" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps_g.c.obj.d"
  "C:/ECE520/LAB2/axi_gpio_vitis/platform/ps7_cortexa9_0/standalone_ps7_cortexa9_0/bsp/libsrc/dmaps/src/xdmaps_hw.c" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps_hw.c.obj" "gcc" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps_hw.c.obj.d"
  "C:/ECE520/LAB2/axi_gpio_vitis/platform/ps7_cortexa9_0/standalone_ps7_cortexa9_0/bsp/libsrc/dmaps/src/xdmaps_selftest.c" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps_selftest.c.obj" "gcc" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps_selftest.c.obj.d"
  "C:/ECE520/LAB2/axi_gpio_vitis/platform/ps7_cortexa9_0/standalone_ps7_cortexa9_0/bsp/libsrc/dmaps/src/xdmaps_sinit.c" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps_sinit.c.obj" "gcc" "libsrc/dmaps/src/CMakeFiles/dmaps.dir/xdmaps_sinit.c.obj.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
