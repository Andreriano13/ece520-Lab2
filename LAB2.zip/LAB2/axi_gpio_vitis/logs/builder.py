# 2026-09-28T14:53:50.902599200
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/ECE520/LAB2/axi_gpio_vitis")

platform = client.create_platform_component(name = "platform",hw = "C:/ECE520/LAB2/ECE520_Lab2/axi_gpio_ar_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0")

platform = client.get_platform_component(name="platform")
status = platform.build()

comp = client.create_app_component(name="axi_gpio_app",platform = "C:/ECE520/LAB2/axi_gpio_vitis/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0")

comp = client.get_component(name="axi_gpio_app")
comp.build()

comp.build()

vitis.dispose()

vitis.dispose()

